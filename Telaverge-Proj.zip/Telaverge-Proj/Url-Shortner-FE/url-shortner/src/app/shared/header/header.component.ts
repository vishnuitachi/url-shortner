import { Component } from '@angular/core';
import { LoginComponent } from '../../auth/login/login.component';
import { MatDialog } from '@angular/material/dialog';
import { RegisterComponent } from '../../auth/register/register.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  constructor(
    private dialog: MatDialog,
  ) {
  }

  openLogin(): void {
    this.dialog.open(LoginComponent)
  }
  openRegister(): void {
    this.dialog.open(RegisterComponent)
  }
}
