import { Component, OnInit } from '@angular/core';
import { Url } from '../../model/Url';
import { Router } from '@angular/router';
import { CoreService } from '../../service/core.service';
import { SharedService } from '../../service/shared.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  urls: Url[] = [];

  constructor(
    private dashboardService: CoreService,
    private sharedService: SharedService,
    private router: Router
  ) { }

  ngOnInit() {
    const userId: number | null = parseInt(localStorage.getItem('userId') || '0', 10);
    console.log(userId);
    if (userId) {
      this.dashboardService.fetchUrls(userId).subscribe(
        (response: Url[]) => {
          this.urls = response;
          console.log(response);
        },
        error => {
          console.error('Error fetching URLs:', error);
        }
      );
    } else {
      console.log('Something went wrong');
    }
  }

  openUrl(shortAlias: string) {
    this.dashboardService.openUrl(shortAlias).subscribe(
      url => console.log(url)
    );
  }
}
