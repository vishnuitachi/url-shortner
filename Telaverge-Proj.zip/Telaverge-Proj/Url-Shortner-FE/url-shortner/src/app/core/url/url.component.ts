import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CoreService } from '../../service/core.service';
import Swal from 'sweetalert2';
import { Url } from '../../model/Url';
import { SharedService } from '../../service/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-url',
  templateUrl: './url.component.html',
  styleUrls: ['./url.component.css']
})
export class UrlComponent{
  urlForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private router:Router,
    private urlService: CoreService
  ) {
    this.urlForm = this.formBuilder.group({
      originalUrl: ['', Validators.required]
    });
  }

  submit() {
    console.log("url submitted")
    const urlData = this.urlForm.value
    console.log("url data ",urlData)
      this.urlService.urlShorter(urlData).subscribe(
        () => this.handleSuccess(),
        () => this.handleError()
      );
  }

  handleSuccess() {
    Swal.fire({
      icon: 'success',
      title: 'Mini Url Available to share!',
      timer: 2000,
      showConfirmButton: false
    });
    setTimeout(() => location.reload(), 2000);
  }

  handleError() {
    Swal.fire({
      icon: 'error',
      title: 'Something went wrong!',
      showConfirmButton: true
    });
  }

  navigateToHome(){
    setTimeout(() => {
      this.router.navigate(['/home']);
    }, 2000);
  }
}