export interface Login {
    userId:number
    username: string
    password: string
}