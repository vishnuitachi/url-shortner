export interface Url {
    originalUrl: string,
    shortAlias: string,
    creationDate:Date,
    clicks:number,
    userId:number;
}