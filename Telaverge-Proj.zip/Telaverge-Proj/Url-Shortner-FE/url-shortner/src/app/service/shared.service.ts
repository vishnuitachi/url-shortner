import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private userId!: number;

  setUserData(userId: number) {
    console.log("setUserData ",userId)
    this.userId = userId;
  }

  getUserId() {
    console.log("get userId ", this.userId)
    return this.userId;
  }
}