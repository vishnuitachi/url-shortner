import { Injectable } from '@angular/core';
import { Url } from '../model/Url';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoreService {
  private baseUrl = 'http://localhost:8081/api/url';

  constructor(private http: HttpClient) { }

  urlShorter(urlData: Url): Observable<Url> {
    const userId=localStorage.getItem('userId')
    const urlShorterUrl = `${this.baseUrl}/${userId}`;
    console.log("url service called & data sent")
    console.log("user id in url short ",userId)
    return this.http.post<Url>(urlShorterUrl, urlData);
  }

  fetchUrls(userId: number): Observable<Url[]> {
    const dashboardUrl = `${this.baseUrl}/${userId}`;
    return this.http.get<Url[]>(dashboardUrl);
  }

  openUrl(shortAlias: string): Observable<Url> {
    const dashboardUrl = `http://localhost:8081/minify/${shortAlias}`;
    console.log(dashboardUrl)
    return this.http.get<Url>(dashboardUrl);
  }
}
