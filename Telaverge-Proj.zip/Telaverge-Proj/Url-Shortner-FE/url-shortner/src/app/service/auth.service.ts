import { Injectable } from '@angular/core';
import { Login } from '../model/Login';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = 'http://localhost:8081/api/user';

  constructor(private http: HttpClient) { }

  login(loginData: Login): Observable<Login> {
    const loginUrl=`${this.baseUrl}/login`
    return this.http.post<Login>(loginUrl, loginData)
  }

  register(registerData: Login): Observable<Login> {
    const registerUrl=`${this.baseUrl}/register`
    return this.http.post<Login>(registerUrl, registerData);
  }
}