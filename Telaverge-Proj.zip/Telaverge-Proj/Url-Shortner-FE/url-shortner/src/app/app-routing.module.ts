import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { DashboardComponent } from './core/dashboard/dashboard.component';
import { UrlComponent } from './core/url/url.component';
import { HeaderComponent } from './shared/header/header.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  // { path: 'login', redirectTo: 'http://localhost:8081/api/user/login', pathMatch: 'full'},
  { path: 'url', component: UrlComponent },
  { path: 'home', component: HeaderComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
