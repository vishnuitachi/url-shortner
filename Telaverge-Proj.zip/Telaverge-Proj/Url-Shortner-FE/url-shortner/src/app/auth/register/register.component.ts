import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AuthService } from '../../service/auth.service';
import { Login } from '../../model/Login';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  registerForm!: FormGroup;

  constructor(
    private dialogRef: MatDialogRef<RegisterComponent>,
    private fb: FormBuilder,
    private authService: AuthService
  ) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const passwordControl = formGroup.get('password');
    const confirmPasswordControl = formGroup.get('confirmPassword');

    if (passwordControl && confirmPasswordControl) {
      const password = passwordControl.value;
      const confirmPassword = confirmPasswordControl.value;

      if (password !== confirmPassword) {
        confirmPasswordControl.setErrors({ mismatch: true });
      } else {
        confirmPasswordControl.setErrors(null);
      }
    }
  }

  submit() {
    if (this.registerForm.valid) {
      const registerData: Login = this.registerForm.value;
      this.authService.register(registerData).subscribe(
        () => this.handleSuccess(),
        () => this.handleError()
      );
    }
  }

  handleSuccess() {
    Swal.fire({
      icon: 'success',
      title: 'User Register Successful!',
      timer: 2000,
      showConfirmButton: false
    });
    this.dialogRef.close();
    setTimeout(() => location.reload(), 2000);
  }

  handleError() {
    Swal.fire({
      icon: 'error',
      title: 'Something went wrong!',
      showConfirmButton: true
    });
  }

  cancel() {
    this.dialogRef.close();
  }
}
