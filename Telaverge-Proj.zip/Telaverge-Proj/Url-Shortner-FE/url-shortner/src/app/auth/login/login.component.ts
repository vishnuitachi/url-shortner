import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AuthService } from '../../service/auth.service';
import { Login } from '../../model/Login';
import Swal from 'sweetalert2';
import { Route, Router } from '@angular/router';
import { SharedService } from '../../service/shared.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm!: FormGroup

  constructor(
    private dialogRef: MatDialogRef<LoginComponent>,
    private formBuilder: FormBuilder,
    private loginService: AuthService,
    private sharedService:SharedService,
    private router:Router
  ) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  cancel() {
    this.dialogRef.close();
  }

  submit() {
    console.log("login submit clicked")
    if (this.loginForm.valid) {
      const loginData: Login = this.loginForm.value;
      this.loginService.login(loginData).subscribe(
        (response:Login) => {
          this.handleSuccess();
          localStorage.setItem('userId', `${response.userId}`);
          this.sharedService.setUserData(response.userId)
        },
        () => this.handleError()
      );
    }
  }
  

  handleSuccess() {
    console.log("login sc")
    Swal.fire({
      icon: 'success',
      title: 'Login Successful!',
      timer: 2000,
      showConfirmButton: false
    });
    this.dialogRef.close();
    setTimeout(() => {
      this.router.navigate(['/url']);
    }, 2000);
    setTimeout(() => location.reload(), 2000);
  }

  handleError() {
    console.log("login ec")
    Swal.fire({
      icon: 'error',
      title: 'Something went wrong!',
      showConfirmButton: true
    });
  }

}