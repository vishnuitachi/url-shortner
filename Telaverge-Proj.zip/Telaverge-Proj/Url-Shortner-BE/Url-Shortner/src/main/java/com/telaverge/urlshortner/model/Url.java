package com.telaverge.urlshortner.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Url {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long urlId;

    @Column(unique = true,length = 1000)
    private String originalUrl;

    @Column(unique = true)
    private String shortAlias;

    @ManyToOne
    private User user;

    @CreationTimestamp
    private LocalDate creationDate;

    @OneToMany(mappedBy = "url")
    private List<Click> clicks;
}