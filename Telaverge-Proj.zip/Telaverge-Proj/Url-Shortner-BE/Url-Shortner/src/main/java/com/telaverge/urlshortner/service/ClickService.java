package com.telaverge.urlshortner.service;

import com.telaverge.urlshortner.payload.response.ClickResponse;
import jakarta.servlet.http.HttpServletRequest;

public interface ClickService {
    ClickResponse urlClickAction(Long urlId, HttpServletRequest request);
}