package com.telaverge.urlshortner.exception;

import com.telaverge.urlshortner.payload.response.ExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ExceptionResponse> userNotFound(UserNotFoundException exception){
        ExceptionResponse exceptionResponse=new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptionResponse);
    }

    @ExceptionHandler(UrlNotFoundException.class)
    public ResponseEntity<ExceptionResponse> urlNotFound(UrlNotFoundException exception){
        ExceptionResponse exceptionResponse=new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptionResponse);
    }

    @ExceptionHandler(ResourceCreationFailedException.class)
    public ResponseEntity<ExceptionResponse> resourceCreateFailed(ResourceCreationFailedException exception){
        ExceptionResponse exceptionResponse=new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptionResponse);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ExceptionResponse> illegalArguement(IllegalArgumentException exception){
        ExceptionResponse exceptionResponse=new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptionResponse);
    }

}
