package com.telaverge.urlshortner.repository;

import com.telaverge.urlshortner.model.Click;
import com.telaverge.urlshortner.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClickRepository extends JpaRepository<Click,Long> {
}