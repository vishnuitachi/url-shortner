package com.telaverge.urlshortner.serviceImpl;

import com.telaverge.urlshortner.exception.ResourceCreationFailedException;
import com.telaverge.urlshortner.exception.UrlNotFoundException;
import com.telaverge.urlshortner.model.Click;
import com.telaverge.urlshortner.model.Url;
import com.telaverge.urlshortner.model.User;
import com.telaverge.urlshortner.payload.response.ClickResponse;
import com.telaverge.urlshortner.repository.ClickRepository;
import com.telaverge.urlshortner.repository.UrlRepository;
import com.telaverge.urlshortner.repository.UserRepository;
import com.telaverge.urlshortner.service.ClickService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClickServiceImpl implements ClickService {
    private final ModelMapper mapper;

    private final ClickRepository clickRepo;
    private final UserRepository userRepo;
    private final UrlRepository urlRepo;

    @Override
    public ClickResponse urlClickAction(Long urlId, HttpServletRequest request) {
        log.info("url clicked");
        User user = userRepo.findByUsername(currentLoginUser()).get();

        Url url = urlRepo.findById(urlId)
                .orElseThrow(() -> new UrlNotFoundException("URL not found"));

        String referralSource = null;

        try {
            referralSource = fetchHost(request);
        } catch (IOException e) {
            throw new ResourceCreationFailedException("Error fetching referral source");
        }

        Click click = new Click();
        click.setUser(user);
        click.setUrl(url);
        click.setReferralSource(referralSource);

        click = clickRepo.save(click);
        return mapper.map(click, ClickResponse.class);
    }

    private String currentLoginUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }

    public String fetchHost(HttpServletRequest request) throws IOException {
        try {
            String referer = request.getHeader("referer");
            if (referer != null) {
                URI refererUri = new URI(referer);
                String host = refererUri.getHost();
                if (host != null)
                    return host.startsWith("www.") ? host.substring(4) : host;
            }
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return "unknown";
    }
}
