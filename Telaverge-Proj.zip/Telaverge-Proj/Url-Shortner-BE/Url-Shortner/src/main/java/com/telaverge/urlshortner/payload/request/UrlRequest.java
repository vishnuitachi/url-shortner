package com.telaverge.urlshortner.payload.request;

import com.telaverge.urlshortner.model.User;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UrlRequest {
    @NotBlank(message = "Original URL must not be blank")
    @Pattern(regexp = "^(http|https)://.*$",
             message = "Original URL must start with http:// or https://")
    private String originalUrl;
}