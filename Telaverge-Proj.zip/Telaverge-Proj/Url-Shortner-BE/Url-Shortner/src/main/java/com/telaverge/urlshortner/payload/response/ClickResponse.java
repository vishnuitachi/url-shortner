package com.telaverge.urlshortner.payload.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClickResponse {
    private Long userId;
    private Long urlId;
    private String referralSource;
}