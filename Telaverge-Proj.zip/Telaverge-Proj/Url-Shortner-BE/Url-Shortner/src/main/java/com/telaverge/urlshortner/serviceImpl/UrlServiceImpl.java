package com.telaverge.urlshortner.serviceImpl;

import com.telaverge.urlshortner.exception.ResourceCreationFailedException;
import com.telaverge.urlshortner.exception.UrlNotFoundException;
import com.telaverge.urlshortner.exception.UserNotFoundException;
import com.telaverge.urlshortner.model.Url;
import com.telaverge.urlshortner.model.User;
import com.telaverge.urlshortner.payload.request.UrlRequest;
import com.telaverge.urlshortner.payload.response.ClickResponse;
import com.telaverge.urlshortner.payload.response.UrlResponse;
import com.telaverge.urlshortner.repository.UrlRepository;
import com.telaverge.urlshortner.repository.UserRepository;
import com.telaverge.urlshortner.service.ClickService;
import com.telaverge.urlshortner.service.UrlService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UrlServiceImpl implements UrlService {
    private final UrlRepository urlRepo;
    private final ModelMapper mapper;
    private final UserRepository userRepo;

    @Override
    public UrlResponse createUrl(UrlRequest urlRequest, Long userId) {
        log.info("inside url service impl create");
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        String username = authentication.getName();
        if (urlRequest == null)
            throw new IllegalArgumentException("UrlRequest cannot be null");
        User user = userRepo.findById(userId).orElseThrow(
                () -> new UserNotFoundException("user not found")
        );
        try {
            Url url = mapper.map(urlRequest, Url.class);
            url.setShortAlias(urlRepo.urlAliasGenerator());
            url.setUser(user);
            url = urlRepo.save(url);
            return mapper.map(url, UrlResponse.class);
        } catch (Exception e) {
            throw new ResourceCreationFailedException("URL Creation Failed");
        }
    }

    @Override
    public void fetchUrlFromAlias(String urlAlias, HttpServletResponse response) {
        Url url = urlRepo.findByShortAlias(urlAlias).orElseThrow(
                () -> new UrlNotFoundException("URL not found")
        );
        try {
            String youtubeUrl = url.getOriginalUrl();
            response.sendRedirect(youtubeUrl);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<UrlResponse> fetchUrlByUserId(Long userId) {
        User user = userRepo.findById(userId).orElseThrow(
                () -> new UserNotFoundException("user not found")
        );
        List<Url> urls = urlRepo.findByUser(user).orElseThrow(
                () -> new UrlNotFoundException("urls with user not found")
        );
        return urls.stream()
                .map(url -> mapper.map(url, UrlResponse.class))
                .collect(Collectors.toList());
    }
}