package com.telaverge.urlshortner.service;

import com.telaverge.urlshortner.payload.request.UrlRequest;
import com.telaverge.urlshortner.payload.response.UrlResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

public interface UrlService {
    UrlResponse createUrl(UrlRequest urlRequest,Long userId);
    void fetchUrlFromAlias(String urlAlias, HttpServletResponse response) throws IOException;

    List<UrlResponse> fetchUrlByUserId(Long userId);
}