package com.telaverge.urlshortner.repository;

import com.telaverge.urlshortner.model.Click;
import com.telaverge.urlshortner.model.Url;
import com.telaverge.urlshortner.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UrlRepository extends JpaRepository<Url, Long> {
    @Query(value = "SELECT SUBSTRING(MD5(RAND()),1,5) AS url_alias", nativeQuery = true)
    String urlAliasGenerator();

    Optional<Url> findByShortAlias(String urlAlias);

    Optional<List<Url>> findByUser(User user);
}