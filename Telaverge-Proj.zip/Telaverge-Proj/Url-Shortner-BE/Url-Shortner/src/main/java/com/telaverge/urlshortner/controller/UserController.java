package com.telaverge.urlshortner.controller;

import com.telaverge.urlshortner.exception.UserNotFoundException;
import com.telaverge.urlshortner.model.User;
import com.telaverge.urlshortner.payload.request.UserRequest;
import com.telaverge.urlshortner.payload.response.UserResponse;
import com.telaverge.urlshortner.repository.UserRepository;
import com.telaverge.urlshortner.serviceImpl.CustomUserDetailsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/user")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class UserController {
    private final CustomUserDetailsService userService;
    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final ModelMapper mapper;

    @PostMapping(value = "/login")
    public ResponseEntity<UserResponse> signin(@RequestBody @Valid UserRequest request) {
        User user = validateCredentials(request);
        userService.loadUserByUsername(request.getUsername());
        return ResponseEntity.ok().body(mapper.map(user, UserResponse.class));
    }

    @PostMapping("/register")
    public ResponseEntity<UserResponse> signup(@RequestBody @Valid UserRequest request) {
        return ResponseEntity.ok().body(userService.signup(request));
    }

    private User validateCredentials(UserRequest request) {
        User user = userRepo.findByUsername(request.getUsername()).orElseThrow(
                () -> new UserNotFoundException("invalid credentials")
        );
        if (!encoder.matches(request.getPassword(), user.getPassword()))
            throw new UserNotFoundException("invalid credentials");
        return user;
    }
}