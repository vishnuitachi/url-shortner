package com.telaverge.urlshortner.controller;

import com.telaverge.urlshortner.payload.request.UrlRequest;
import com.telaverge.urlshortner.payload.response.UrlResponse;
import com.telaverge.urlshortner.service.UrlService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class UrlController {
    private final UrlService urlService;

    @PostMapping("/api/url/{userId}")
    public ResponseEntity<UrlResponse> createUrl(@RequestBody @Valid UrlRequest urlRequest,@PathVariable Long userId) {
        log.info("backend url created called");
        return ResponseEntity.ok().body(urlService.createUrl(urlRequest,userId));
    }

    @Operation(hidden = true)
    @GetMapping(value = "/minify/{urlAlias}")
    public void fetchUrlFromAlias(@PathVariable String urlAlias, HttpServletResponse response) throws IOException {
        urlService.fetchUrlFromAlias(urlAlias,response);
    }

    @GetMapping(value = "/api/url/{userId}")
    public ResponseEntity<List<UrlResponse>> fetchUrlByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok().body(urlService.fetchUrlByUserId(userId));
    }
}
