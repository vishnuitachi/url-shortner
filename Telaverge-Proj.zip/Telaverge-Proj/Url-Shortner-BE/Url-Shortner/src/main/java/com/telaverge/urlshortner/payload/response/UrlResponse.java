package com.telaverge.urlshortner.payload.response;

import com.telaverge.urlshortner.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UrlResponse {
    private Long urlId;
    private String originalUrl;
    private String shortAlias;
    private LocalDate creationDate;
}