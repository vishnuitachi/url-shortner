package com.telaverge.urlshortner.controller;

import com.telaverge.urlshortner.payload.response.ClickResponse;
import com.telaverge.urlshortner.service.ClickService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

@RestController
@RequestMapping(value = "/api/click")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class ClickController {
    private final ClickService clickService;

    @PostMapping
    public ResponseEntity<ClickResponse> urlClickAction(
            @RequestParam Long urlId,
            HttpServletRequest request
    ) {
        return ResponseEntity.ok().body(clickService.urlClickAction(urlId,request));
    }
}