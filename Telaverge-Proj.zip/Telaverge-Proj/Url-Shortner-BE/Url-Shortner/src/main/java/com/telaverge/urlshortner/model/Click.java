package com.telaverge.urlshortner.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Click {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long clickId;

    @ManyToOne
    private Url url;

    @ManyToOne
    private User user;

    @CreationTimestamp
    private LocalDate clickDateTime;
    private String referralSource;
}