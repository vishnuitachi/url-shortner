package com.telaverge.urlshortner.serviceImpl;

import com.telaverge.urlshortner.model.User;
import com.telaverge.urlshortner.payload.request.UserRequest;
import com.telaverge.urlshortner.payload.response.UserResponse;
import com.telaverge.urlshortner.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomUserDetailsService implements UserDetailsService{
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private ModelMapper mapper;

    @Autowired
    private PasswordEncoder encoder;

    public UserResponse signup(UserRequest userRequest) {
        if (userRequest == null)
            return null;
        User user = mapper.map(userRequest, User.class);
        user.setPassword(encoder.encode(userRequest.getPassword()));
        userRepo.save(user);
        return mapper.map(user, UserResponse.class);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User userData = userRepo.findByUsername(username).orElseThrow(
                () -> new UsernameNotFoundException("username does not exist")
        );

        log.info("impl {}, {}",userData.getUsername(),userData.getPassword());
        return new org.springframework.security.core.userdetails.User(
                userData.getUsername(),
                userData.getPassword(),
                Collections.emptyList()
        );
    }
}
